<?php

return array(
	'default' => 'mysql',
	'prefix' => 'ed_',
	'connections' => array(
		'mysql' => array(
			'driver' => 'mysql',
			'hostname' => '127.0.0.1',
			'port' => 3306,
			'username' => 'root',
			'password' => '',
			'database' => 'smp',
			'charset' => 'utf8'
		)
	),
	//'profiling' => true,
);
